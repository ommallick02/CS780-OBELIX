"""
DRQN (Deep Recurrent Q-Network) Agent with LSTM for OBELIX.

This agent loads pretrained LSTM weights and uses them for evaluation.
The LSTM maintains temporal memory across steps within an episode.
"""

from __future__ import annotations
from typing import List, Optional, Tuple
import os
import numpy as np
import torch
import torch.nn as nn

ACTIONS: List[str] = ["L45", "L22", "FW", "R22", "R45"]


class LSTMDQN(nn.Module):
    """LSTM-based DQN for temporal memory."""

    def __init__(self, in_dim: int = 18, hidden_dim: int = 64, n_actions: int = 5):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.lstm = nn.LSTM(in_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, n_actions)

    def forward(self, x: torch.Tensor, hidden: Tuple[torch.Tensor, torch.Tensor] = None):
        if x.dim() == 2:
            x = x.unsqueeze(1)

        if hidden is None:
            lstm_out, hidden = self.lstm(x)
        else:
            lstm_out, hidden = self.lstm(x, hidden)

        q_values = self.fc(lstm_out[:, -1, :])
        return q_values, hidden

    def init_hidden(self, batch_size: int = 1, device: str = "cpu"):
        h = torch.zeros(1, batch_size, self.hidden_dim, device=device)
        c = torch.zeros(1, batch_size, self.hidden_dim, device=device)
        return (h, c)


# Global state
_model: Optional[LSTMDQN] = None
_hidden: Optional[Tuple[torch.Tensor, torch.Tensor]] = None
_last_action: Optional[int] = None
_repeat_count: int = 0

_MAX_REPEAT = 2
_CLOSE_Q_DELTA = 0.05


def _load_once():
    global _model, _hidden
    if _model is not None:
        return

    here = os.path.dirname(__file__)
    wpath = os.path.join(here, "weights.pth")

    if not os.path.exists(wpath):
        raise FileNotFoundError(
            "weights.pth not found next to agent.py. Train offline and include it in the submission zip."
        )

    # Load with default hidden_dim=64 (can be adjusted if needed)
    m = LSTMDQN(in_dim=18, hidden_dim=64, n_actions=5)
    sd = torch.load(wpath, map_location="cpu")
    m.load_state_dict(sd, strict=True)
    m.eval()

    _model = m
    _hidden = None  # Will be initialized on first call


@torch.no_grad()
def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
    global _model, _hidden, _last_action, _repeat_count

    _load_once()

    # Initialize hidden state at start of episode (first call)
    if _hidden is None:
        _hidden = _model.init_hidden(batch_size=1, device="cpu")

    # Prepare input
    x = torch.tensor(obs, dtype=torch.float32).unsqueeze(0).unsqueeze(0)

    # Forward pass with current hidden state
    q, _hidden = _model(x, _hidden)
    q = q.squeeze(0).cpu().numpy()

    # Detach hidden state to prevent graph buildup
    _hidden = (_hidden[0].detach(), _hidden[1].detach())

    best = int(np.argmax(q))

    # Smoothing: if top-2 Qs are close, avoid flip-flopping
    if _last_action is not None:
        order = np.argsort(-q)
        best_q, second_q = float(q[order[0]]), float(q[order[1]])
        if (best_q - second_q) < _CLOSE_Q_DELTA:
            if _repeat_count < _MAX_REPEAT:
                best = _last_action
                _repeat_count += 1
            else:
                _repeat_count = 0
        else:
            _repeat_count = 0

    _last_action = best
    return ACTIONS[best]
